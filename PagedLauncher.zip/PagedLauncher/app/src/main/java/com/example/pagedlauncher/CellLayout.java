package com.example.pagedlauncher;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/**
 * 1ページ分の4×4グリッド。子ビューを左上から右へ、行ごとに並べる。
 * 余白を除いた領域を均等に16分割するので、画面サイズや向きが変わってもぴったり収まる。
 */
public class CellLayout extends ViewGroup {

    public static final int COLUMNS = 4;
    public static final int ROWS = 4;

    private int cellWidth;
    private int cellHeight;

    public CellLayout(Context context) {
        super(context);
        final int pad = (int) (6 * context.getResources().getDisplayMetrics().density);
        setPadding(pad, pad, pad, pad);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        final int width = MeasureSpec.getSize(widthMeasureSpec);
        final int height = MeasureSpec.getSize(heightMeasureSpec);

        cellWidth = Math.max(0, (width - getPaddingLeft() - getPaddingRight()) / COLUMNS);
        cellHeight = Math.max(0, (height - getPaddingTop() - getPaddingBottom()) / ROWS);

        final int childWidthSpec = MeasureSpec.makeMeasureSpec(cellWidth, MeasureSpec.EXACTLY);
        final int childHeightSpec = MeasureSpec.makeMeasureSpec(cellHeight, MeasureSpec.EXACTLY);
        final int count = getChildCount();
        for (int i = 0; i < count; i++) {
            getChildAt(i).measure(childWidthSpec, childHeightSpec);
        }
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        final int count = getChildCount();
        for (int i = 0; i < count; i++) {
            final View child = getChildAt(i);
            final int col = i % COLUMNS;
            final int row = i / COLUMNS;
            final int left = getPaddingLeft() + col * cellWidth;
            final int top = getPaddingTop() + row * cellHeight;
            child.layout(left, top, left + cellWidth, top + cellHeight);
        }
    }
}
