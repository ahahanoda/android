package com.example.pagedlauncher;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** アイコンとラベルを縦に並べた、グリッド1マス分のビュー。 */
public class AppItemView extends LinearLayout {

    private static final int ICON_DP = 48;

    private final AppInfo appInfo;
    private final ImageView iconView;
    private final int maxIconSize;

    public AppItemView(Context context, AppInfo appInfo) {
        super(context);
        this.appInfo = appInfo;

        final float density = context.getResources().getDisplayMetrics().density;
        maxIconSize = (int) (ICON_DP * density);
        final int pad = (int) (2 * density);

        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER);
        setPadding(pad, pad, pad, pad);
        setBackgroundResource(R.drawable.item_bg);
        setClickable(true);
        setFocusable(true); // トラックボール/十字キー操作用

        iconView = new ImageView(context);
        iconView.setImageDrawable(appInfo.icon);
        iconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        addView(iconView, new LinearLayout.LayoutParams(maxIconSize, maxIconSize));

        final TextView labelView = new TextView(context);
        labelView.setText(appInfo.label);
        labelView.setTextColor(Color.WHITE);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        labelView.setSingleLine(true);
        labelView.setEllipsize(TextUtils.TruncateAt.END);
        labelView.setGravity(Gravity.CENTER);
        labelView.setShadowLayer(2f, 0f, 1f, 0xCC000000); // 壁紙の上でも読めるように
        final LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = (int) (2 * density);
        addView(labelView, labelParams);
    }

    public AppInfo getAppInfo() {
        return appInfo;
    }

    /** マスの高さが足りない場合(横向きなど)は、アイコンを縮めてラベルが切れないようにする。 */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        final int height = MeasureSpec.getSize(heightMeasureSpec);
        final int size = Math.min(maxIconSize, (int) (height * 0.56f));
        final ViewGroup.LayoutParams lp = iconView.getLayoutParams();
        lp.width = size;
        lp.height = size;
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }
}
