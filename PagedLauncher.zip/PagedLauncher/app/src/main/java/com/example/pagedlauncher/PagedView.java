package com.example.pagedlauncher;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Scroller;

/**
 * 横スワイプでページ送りできるViewGroup。
 * ViewPager(サポートライブラリ)を使わず、Android 2.3 (API 9) の標準APIだけで実装している。
 * 子ビューが1ページずつ、画面と同じ大きさで横に並ぶ。
 */
public class PagedView extends ViewGroup {

    public interface OnPageChangeListener {
        /** 表示中のページ(画面に最も大きく見えているページ)が変わったときに呼ばれる。 */
        void onPageChanged(int page);
    }

    private static final int INVALID_POINTER = -1;
    private static final int TOUCH_REST = 0;
    private static final int TOUCH_SCROLLING = 1;

    /** これより速い指の動き(dp/秒)ならフリックとして扱い、ページ送りする。 */
    private static final int FLING_VELOCITY_DP = 300;
    private static final int MIN_SNAP_MS = 120;
    private static final int MAX_SNAP_MS = 300;

    private final Scroller scroller;
    private final int touchSlop;
    private final int flingVelocity;
    private final int maxVelocity;

    private VelocityTracker velocityTracker;
    private int touchState = TOUCH_REST;
    private int activePointerId = INVALID_POINTER;
    private float lastMotionX;

    private int currentPage;
    private OnPageChangeListener pageChangeListener;

    public PagedView(Context context) {
        this(context, null);
    }

    public PagedView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PagedView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        final ViewConfiguration configuration = ViewConfiguration.get(context);
        touchSlop = configuration.getScaledTouchSlop();
        maxVelocity = configuration.getScaledMaximumFlingVelocity();
        flingVelocity = (int) (FLING_VELOCITY_DP
                * context.getResources().getDisplayMetrics().density);
        scroller = new Scroller(context, new DecelerateInterpolator(1.6f));
    }

    // ------------------------------------------------------------------
    // 公開API
    // ------------------------------------------------------------------

    public void setOnPageChangeListener(OnPageChangeListener listener) {
        pageChangeListener = listener;
    }

    public int getPageCount() {
        return getChildCount();
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void removeAllPages() {
        scroller.abortAnimation();
        removeAllViews();
    }

    /** アニメーションなしで指定ページへ移動する(範囲外なら端のページにそろえる)。 */
    public void setCurrentPage(int page) {
        scroller.abortAnimation();
        final int old = currentPage;
        currentPage = clamp(page, 0, Math.max(0, getChildCount() - 1));
        scrollTo(currentPage * getWidth(), 0);
        if (old != currentPage && pageChangeListener != null) {
            pageChangeListener.onPageChanged(currentPage);
        }
    }

    /** アニメーションつきで指定ページへ移動する。 */
    public void snapToPage(int page) {
        final int width = getWidth();
        if (width <= 0) {
            setCurrentPage(page);
            return;
        }
        final int target = clamp(page, 0, Math.max(0, getChildCount() - 1));
        final int dx = target * width - getScrollX();
        if (dx == 0) {
            return;
        }
        final float ratio = Math.min(1f, Math.abs(dx) / (float) width);
        final int duration = MIN_SNAP_MS + (int) ((MAX_SNAP_MS - MIN_SNAP_MS) * ratio);
        scroller.startScroll(getScrollX(), 0, dx, 0, duration);
        invalidate();
    }

    // ------------------------------------------------------------------
    // レイアウト
    // ------------------------------------------------------------------

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        final int width = MeasureSpec.getSize(widthMeasureSpec);
        final int height = MeasureSpec.getSize(heightMeasureSpec);
        final int childWidthSpec = MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY);
        final int childHeightSpec = MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY);
        final int count = getChildCount();
        for (int i = 0; i < count; i++) {
            getChildAt(i).measure(childWidthSpec, childHeightSpec);
        }
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        final int width = r - l;
        final int height = b - t;
        final int count = getChildCount();
        for (int i = 0; i < count; i++) {
            getChildAt(i).layout(i * width, 0, (i + 1) * width, height);
        }
    }

    /** 画面の向きが変わって幅が変わっても、今のページに留まるようにする。 */
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        scroller.abortAnimation();
        scrollTo(currentPage * w, 0);
    }

    // ------------------------------------------------------------------
    // スクロール
    // ------------------------------------------------------------------

    @Override
    public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollTo(scroller.getCurrX(), scroller.getCurrY());
            postInvalidate();
        }
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        final int width = getWidth();
        final int count = getChildCount();
        if (width <= 0 || count == 0) {
            return;
        }
        final int nearest = clamp((l + width / 2) / width, 0, count - 1);
        if (nearest != currentPage) {
            currentPage = nearest;
            if (pageChangeListener != null) {
                pageChangeListener.onPageChanged(nearest);
            }
        }
    }

    // ------------------------------------------------------------------
    // タッチ処理
    // ------------------------------------------------------------------

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (getChildCount() == 0) {
            return false;
        }
        final int action = ev.getAction();
        if (action == MotionEvent.ACTION_MOVE && touchState == TOUCH_SCROLLING) {
            return true;
        }
        acquireVelocityTracker(ev);

        switch (action & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                lastMotionX = ev.getX();
                activePointerId = ev.getPointerId(0);
                // 動いている最中のページを指で止められるようにする
                touchState = scroller.isFinished() ? TOUCH_REST : TOUCH_SCROLLING;
                break;

            case MotionEvent.ACTION_MOVE:
                maybeStartScrolling(ev);
                break;

            case MotionEvent.ACTION_POINTER_UP:
                onSecondaryPointerUp(ev);
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                touchState = TOUCH_REST;
                activePointerId = INVALID_POINTER;
                releaseVelocityTracker();
                break;
        }
        return touchState != TOUCH_REST;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (getChildCount() == 0) {
            return super.onTouchEvent(ev);
        }
        acquireVelocityTracker(ev);

        switch (ev.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                if (!scroller.isFinished()) {
                    scroller.abortAnimation();
                    touchState = TOUCH_SCROLLING;
                }
                lastMotionX = ev.getX();
                activePointerId = ev.getPointerId(0);
                break;

            case MotionEvent.ACTION_MOVE:
                if (touchState == TOUCH_SCROLLING) {
                    final int index = ev.findPointerIndex(activePointerId);
                    if (index < 0) {
                        break;
                    }
                    final float x = ev.getX(index);
                    final int dx = (int) (lastMotionX - x);
                    if (dx != 0) {
                        lastMotionX -= dx; // 端数は次回に持ち越す
                        final int maxScroll = Math.max(0, (getChildCount() - 1) * getWidth());
                        scrollTo(clamp(getScrollX() + dx, 0, maxScroll), 0);
                    }
                } else {
                    maybeStartScrolling(ev);
                }
                break;

            case MotionEvent.ACTION_UP:
                if (touchState == TOUCH_SCROLLING) {
                    velocityTracker.computeCurrentVelocity(1000, maxVelocity);
                    final int velocityX = (int) velocityTracker.getXVelocity(activePointerId);
                    finishDrag(velocityX);
                }
                endTouch();
                break;

            case MotionEvent.ACTION_CANCEL:
                if (touchState == TOUCH_SCROLLING) {
                    finishDrag(0);
                }
                endTouch();
                break;

            case MotionEvent.ACTION_POINTER_UP:
                onSecondaryPointerUp(ev);
                break;
        }
        return true;
    }

    /** 横方向にスロップ以上動いたらドラッグ開始とみなす。 */
    private void maybeStartScrolling(MotionEvent ev) {
        final int index = ev.findPointerIndex(activePointerId);
        if (index < 0) {
            return;
        }
        final float x = ev.getX(index);
        if (Math.abs(x - lastMotionX) > touchSlop) {
            touchState = TOUCH_SCROLLING;
            lastMotionX = x;
        }
    }

    /** 指を離したとき、どのページに止めるかを決めて移動する。 */
    private void finishDrag(int velocityX) {
        final int width = getWidth();
        if (width <= 0) {
            return;
        }
        final float position = getScrollX() / (float) width;
        final int target;
        if (Math.abs(velocityX) > flingVelocity) {
            // フリック: 指を動かした向きの隣のページへ
            target = velocityX < 0
                    ? (int) Math.floor(position) + 1
                    : (int) Math.ceil(position) - 1;
        } else {
            // ゆっくり離した: 一番近いページへ
            target = Math.round(position);
        }
        snapToPage(target);
    }

    private void endTouch() {
        touchState = TOUCH_REST;
        activePointerId = INVALID_POINTER;
        releaseVelocityTracker();
    }

    /** 2本目の指が離れたとき、残った指に追従を引き継ぐ。 */
    private void onSecondaryPointerUp(MotionEvent ev) {
        final int pointerIndex = (ev.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK)
                >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
        if (ev.getPointerId(pointerIndex) == activePointerId) {
            final int newIndex = pointerIndex == 0 ? 1 : 0;
            lastMotionX = ev.getX(newIndex);
            activePointerId = ev.getPointerId(newIndex);
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    private void acquireVelocityTracker(MotionEvent ev) {
        if (velocityTracker == null) {
            velocityTracker = VelocityTracker.obtain();
        }
        velocityTracker.addMovement(ev);
    }

    private void releaseVelocityTracker() {
        if (velocityTracker != null) {
            velocityTracker.recycle();
            velocityTracker = null;
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
