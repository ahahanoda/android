package com.example.pagedlauncher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** 画面下部の「●○○」のようなページ位置表示。 */
public class PageIndicator extends View {

    private final Paint activePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inactivePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float radius;
    private final float gap;

    private int pageCount;
    private int currentPage;

    public PageIndicator(Context context) {
        this(context, null);
    }

    public PageIndicator(Context context, AttributeSet attrs) {
        super(context, attrs);
        final float density = context.getResources().getDisplayMetrics().density;
        radius = 4 * density;
        gap = 8 * density;
        activePaint.setColor(0xFFFFFFFF);
        inactivePaint.setColor(0x66FFFFFF);
    }

    public void setPageCount(int count) {
        pageCount = Math.max(0, count);
        invalidate();
    }

    public void setCurrentPage(int page) {
        currentPage = page;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (pageCount <= 0) {
            return;
        }
        final float width = getWidth();
        final float centerY = getHeight() / 2f;
        final float diameter = radius * 2;

        // ページ数が多くて収まらない場合は間隔を詰める
        float step = diameter + gap;
        if (pageCount > 1 && (pageCount - 1) * step + diameter > width) {
            step = (width - diameter) / (pageCount - 1);
        }
        final float total = (pageCount - 1) * step + diameter;
        final float startX = (width - total) / 2f + radius;

        for (int i = 0; i < pageCount; i++) {
            canvas.drawCircle(startX + i * step, centerY, radius,
                    i == currentPage ? activePaint : inactivePaint);
        }
    }
}
