package com.example.pagedlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * ホームアプリ本体。インストール済みアプリを1ページ2列×3行で並べ、横スワイプでページを切り替える。
 */
public class LauncherActivity extends Activity
        implements View.OnClickListener, View.OnLongClickListener {

    private static final int MENU_WALLPAPER = 1;
    private static final int MENU_SETTINGS = 2;

    /** アプリの追加・削除は連続して通知されるので、少し待ってからまとめて読み直す。 */
    private static final long RELOAD_DELAY_MS = 400;

    private PagedView pager;
    private PageIndicator indicator;
    private LoadAppsTask loadTask;

    private final Handler handler = new Handler();
    private final Runnable reloadRunnable = new Runnable() {
        @Override
        public void run() {
            loadApps();
        }
    };

    private final BroadcastReceiver packageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            handler.removeCallbacks(reloadRunnable);
            handler.postDelayed(reloadRunnable, RELOAD_DELAY_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.launcher);

        pager = (PagedView) findViewById(R.id.pager);
        indicator = (PageIndicator) findViewById(R.id.indicator);
        pager.setOnPageChangeListener(new PagedView.OnPageChangeListener() {
            @Override
            public void onPageChanged(int page) {
                indicator.setCurrentPage(page);
            }
        });

        final IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addAction(Intent.ACTION_PACKAGE_CHANGED);
        filter.addDataScheme("package");
        registerReceiver(packageReceiver, filter);

        loadApps();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(reloadRunnable);
        unregisterReceiver(packageReceiver);
        if (loadTask != null) {
            loadTask.cancel(true);
        }
    }

    /** ホームボタンを押されたら最初のページへ戻る。 */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (Intent.ACTION_MAIN.equals(intent.getAction())) {
            pager.snapToPage(0);
        }
    }

    /** ホーム画面なので、戻るキーでは何もしない(終了させない)。 */
    @Override
    public void onBackPressed() {
    }

    // ------------------------------------------------------------------
    // メニュー(壁紙・設定)
    // ------------------------------------------------------------------

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_WALLPAPER, 0, R.string.menu_wallpaper)
                .setIcon(android.R.drawable.ic_menu_gallery);
        menu.add(0, MENU_SETTINGS, 1, R.string.menu_settings)
                .setIcon(android.R.drawable.ic_menu_preferences);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case MENU_WALLPAPER:
                startActivitySafely(Intent.createChooser(
                        new Intent(Intent.ACTION_SET_WALLPAPER),
                        getString(R.string.menu_wallpaper)));
                return true;
            case MENU_SETTINGS:
                startActivitySafely(new Intent(Settings.ACTION_SETTINGS));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ------------------------------------------------------------------
    // アプリ一覧の読み込みと表示
    // ------------------------------------------------------------------

    private void loadApps() {
        if (loadTask != null) {
            loadTask.cancel(true);
        }
        loadTask = new LoadAppsTask();
        loadTask.execute();
    }

    private void showApps(List<AppInfo> apps) {
        pager.removeAllPages();

        final int perPage = CellLayout.COLUMNS * CellLayout.ROWS;
        CellLayout page = null;
        for (int i = 0; i < apps.size(); i++) {
            if (i % perPage == 0) {
                page = new CellLayout(this);
                pager.addView(page);
            }
            final AppItemView item = new AppItemView(this, apps.get(i));
            item.setOnClickListener(this);
            item.setOnLongClickListener(this);
            page.addView(item);
        }

        // アプリが減ってページ数が減った場合は、最後のページに寄せる
        pager.setCurrentPage(pager.getCurrentPage());
        indicator.setPageCount(pager.getPageCount());
        indicator.setCurrentPage(pager.getCurrentPage());
    }

    private class LoadAppsTask extends AsyncTask<Void, Void, List<AppInfo>> {

        @Override
        protected List<AppInfo> doInBackground(Void... params) {
            final PackageManager pm = getPackageManager();
            final Intent query = new Intent(Intent.ACTION_MAIN, null);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            final List<ResolveInfo> resolved = pm.queryIntentActivities(query, 0);

            final List<AppInfo> apps = new ArrayList<AppInfo>(resolved.size());
            for (ResolveInfo info : resolved) {
                if (isCancelled()) {
                    return null;
                }
                final ActivityInfo activity = info.activityInfo;
                if (getPackageName().equals(activity.packageName)) {
                    continue; // このランチャー自身は並べない
                }
                CharSequence label = info.loadLabel(pm);
                if (label == null) {
                    label = activity.name;
                }
                apps.add(new AppInfo(label, info.loadIcon(pm),
                        new ComponentName(activity.packageName, activity.name)));
            }

            // 名前順(大文字小文字・濃音などの違いは無視)
            final Collator collator = Collator.getInstance();
            collator.setStrength(Collator.PRIMARY);
            Collections.sort(apps, new Comparator<AppInfo>() {
                @Override
                public int compare(AppInfo a, AppInfo b) {
                    return collator.compare(a.label.toString(), b.label.toString());
                }
            });
            return apps;
        }

        @Override
        protected void onPostExecute(List<AppInfo> apps) {
            if (apps != null) {
                showApps(apps);
            }
        }
    }

    // ------------------------------------------------------------------
    // アプリの起動・長押しメニュー
    // ------------------------------------------------------------------

    @Override
    public void onClick(View v) {
        startActivitySafely(((AppItemView) v).getAppInfo().makeLaunchIntent());
    }

    @Override
    public boolean onLongClick(View v) {
        final AppInfo info = ((AppItemView) v).getAppInfo();
        final CharSequence[] actions = {
                getString(R.string.action_app_info),
                getString(R.string.action_uninstall)
        };
        new AlertDialog.Builder(this)
                .setTitle(info.label)
                .setItems(actions, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final Uri uri = Uri.fromParts("package", info.getPackageName(), null);
                        if (which == 0) {
                            startActivitySafely(new Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri));
                        } else {
                            startActivitySafely(new Intent(Intent.ACTION_DELETE, uri));
                        }
                    }
                })
                .show();
        return true;
    }

    private void startActivitySafely(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.error_launch, Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, R.string.error_launch, Toast.LENGTH_SHORT).show();
        }
    }
}
