package com.example.pagedlauncher;

import android.content.ComponentName;
import android.content.Intent;
import android.graphics.drawable.Drawable;

/** ランチャーに表示する1つのアプリの情報。 */
public class AppInfo {

    public final CharSequence label;
    public final Drawable icon;
    public final ComponentName componentName;

    public AppInfo(CharSequence label, Drawable icon, ComponentName componentName) {
        this.label = label;
        this.icon = icon;
        this.componentName = componentName;
    }

    public String getPackageName() {
        return componentName.getPackageName();
    }

    /** このアプリを起動するためのIntentを作る。 */
    public Intent makeLaunchIntent() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setComponent(componentName);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        return intent;
    }
}
