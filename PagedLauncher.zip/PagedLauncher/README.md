# Paged Launcher (Android 2.3.5 対応)

アプリを **1ページ 4×4** で並べ、**横スワイプ**で次のページに切り替わるホームアプリです。
外部ライブラリは使わず、Android 2.3 (API 9) の標準APIだけで作っています(ViewPagerも不使用)。

## 機能

- 4×4グリッド表示(縦横どちらの向きでも、画面にぴったり16分割)
- 横スワイプ / フリックでページ送り、指を離すと近いページにスナップ
- 下部のページインジケータ(●○○)
- アプリのタップで起動、長押しで「アプリ情報」「アンインストール」
- アプリのインストール/削除を検知して自動で再読み込み
- ホームボタンで1ページ目に戻る / メニューキーで壁紙・設定
- アプリは名前順(日本語対応)

## ビルド

想定している組み合わせ: **Android Gradle Plugin 4.2.2 + Gradle 6.9.x + JDK 8〜11**(このzipは作成環境にAndroid SDKがなく、まだビルド・実機テストをしていません)
(新しいAGPはminSdk 9を扱えない場合があるため、古い組み合わせにしています)

```
gradle wrapper --gradle-version 6.9.4
./gradlew assembleDebug
```

出力: `app/build/outputs/apk/debug/app-debug.apk`

- Android SDK の「Android 11 (API 30)」プラットフォームが必要です。
- 新しいAndroid StudioはAGP 4.2系の読み込みに制限がある場合があります。その場合は上のコマンドラインでのビルドをおすすめします。

## インストールとホームアプリへの設定

```
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

端末のホームボタンを押すと「ホームアプリの選択」が出るので、Paged Launcher を選びます。

## ファイル構成

| ファイル | 役割 |
|---|---|
| `PagedView.java` | 横スワイプでページ送りするViewGroup(タッチ処理・フリック・スナップ) |
| `CellLayout.java` | 1ページ分の4×4グリッド |
| `AppItemView.java` | アイコン+ラベルの1マス |
| `PageIndicator.java` | ページ位置の●表示 |
| `LauncherActivity.java` | アプリ一覧の読み込み、ページ生成、起動・長押しメニュー |
| `AppInfo.java` | アプリ情報(ラベル・アイコン・起動Intent) |
